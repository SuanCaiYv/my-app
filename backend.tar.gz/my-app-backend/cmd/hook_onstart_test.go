package main

import "testing"

func TestInitSysRoleDB(t *testing.T) {
	BeforeStart()
}
