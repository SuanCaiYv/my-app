package main

import "github.com/SuanCaiYv/my-app-backend/api"

func main() {
	BeforeStart()
	api.Route()
}
