package db

const (
	CollectionSysUser   = "sys_user"
	CollectionSysRole   = "sys_role"
	CollectionArticle   = "article"
	CollectionKind      = "article_kind"
	CollectionTag       = "article_tag"
	CollectionOperation = "operation"
)
