package service

import (
	"fmt"
	"testing"
	"time"
)

func TestWSApiHandler_WS(t *testing.T) {
	fmt.Println(int64(time.Second / time.Millisecond))
}
